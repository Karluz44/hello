## AWS Containers - Run Tasks

Note: this costs money

### Objectives

Create a task in ECS to launch in Fargate.

The task itself can be a sample app.
