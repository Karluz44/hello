# My First VPC

## Objectives

1. Create a new VPC
   1. It should have a CIDR that supports using at least 60,000 hosts
   2. It should be named "exercise-vpc"

## Solution

Click [here](solution.md) to view the solution