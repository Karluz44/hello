## No Application :'(

### Objectives

Explain what might be possible reasons for the following issues:

1. Getting "time out" when trying to reach an application running on EC2 instance
2. Getting "connection refused" error
