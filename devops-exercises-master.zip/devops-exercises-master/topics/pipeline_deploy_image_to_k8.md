## Build & Publish Docker Images to Kubernetes Cluster

Write a pipeline, on any CI/CD system you prefer, that will build am image out of a given Dockerfile and will publish that image to running Kubernetes cluster.
