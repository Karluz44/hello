## Deploy to Kubernetes

* Write a pipeline that will deploy an "hello world" web app to Kubernetes 
* The CI/CD system (where the pipeline resides) and the Kubernetes cluster should be on separate systems
* The web app should be accessible remotely and only with HTTPS
