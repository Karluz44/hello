## Highly Available "Hello World"

Set up an highly available "Hello World" application with the following instructions:

* Use a containerized Load Balancer
* Provision two virtual machines (this is where the app will run)
* The page, when visited, should show "Hello World! I'm host X" - X should be the name of the virtual machine

### Solution

1. Provision two VMs
