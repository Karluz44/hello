# Containerized Web Server

1. Run a containerized web server in the background and bind its port (8080) to a local port
2. Verify the port (8080) is bound
3. Reach the webserver from your local host
4. Now run the same web application but bound it to the local port 8080

Click [here for the solution](solutions/containerized_web_server.md)
