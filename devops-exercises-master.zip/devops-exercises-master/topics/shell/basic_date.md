## Basic Date

### Objectives

1. Write a script that will put the current date in a file called "the_date.txt"
