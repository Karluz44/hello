## Class

write a simple class that has two attributes of which one has a default value and has two methods
