## Reverse a String

Write a code that reverses a string
