## (Advanced) Identify the data type

For each of the following, identify what is the data type of the result variable

1. a = {'a', 'b', 'c'}
2. b = {'1': '2'}
4. c = ([1, 2, 3])
4. d = (1, 2, 3)
4. e = True+True
