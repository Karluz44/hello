# Create & Destroy

## Objectives

1. Create a file called `x`
2. Create a directory called `content`
3. Move `x` file to the `content` directory
4. Create a file inside the `content` directory called `y`
5. Create the following directory structure in `content` directory: `dir1/dir2/dir3`
6. Remove the content directory

## Solution

Click [here](solution.md) to view the solution.
