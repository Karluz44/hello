## ReplicaSet 102

#### Objective

Learn how to operate ReplicaSets

#### Instructions

1. Create a ReplicaSet with 2 replicas. The app can be anything.
2. Verify a ReplicaSet was created and there are 2 replicas
3. Remove the ReplicaSet but NOT the pods it created
4. Verify you've deleted the ReplicaSet but the Pods are still running
