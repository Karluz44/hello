## Pods 01 - Solution

```
kubectl run nginx --image=nginx --restart=Never
kubectl get pods
```
