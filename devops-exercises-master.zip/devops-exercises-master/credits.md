## Credits

Jenkins logo created by <a href='https://twitter.com/ks_nenasheva'>Ksenia Nenasheva</a> and published through <a href="https://jenkins.io">jenkins.io</a> is licensed under <a href="https://creativecommons.org/licenses/by-sa/3.0/">cc by-sa 3.0</a><br>
Git Logo by <a href="https://twitter.com/jasonlong">Jason Long</a> is licensed under the <a href="https://creativecommons.org/licenses/by/3.0/">Creative Commons Attribution 3.0 Unported License</a><br>
Terraform logo created by <a href="https://www.hashicorp.com">Hashicorp®</a><br>
Docker logo created by <a href="https://www.docker.com">Docker®</a><br>
The Python logo is a trademark of the Python Software Foundation®<br>
Puppet logo created by <a href="https://puppet.com">Puppet®</a><br>
Bash logo created by Prospect One<br>
OpenStack logo created by and a trademark of The <a href="https://www.openstack.org">OpenStack Foundation®</a><br>
Linux, Kubernetes and Prometheus logos are trademarks of The Linux Foundation®<br>
Mongo logo is a trademark of <a href="http://www.mongodb.com">Mongo®</a><br>
Distributed logo by <a href="https://www.iconfinder.com/Flatart">Flatart</a><br>
Challenge icon by Elizabeth Arostegui in Technology Mix
"Question you ask" (man raising hand) and "Database" icons by [Webalys](https://www.iconfinder.com/webalys)
Testing logo by [Flatart](https://www.iconfinder.com/Flatart)<br>
Google Cloud Plataform Logo created by <a href="https://about.google/">Google®</a><br>
VirtualBox Logo created by <a href="http://www.iconarchive.com/artist/dakirby309.html">dAKirby309</a>, under the <a href="https://creativecommons.org/licenses/by-nc/4.0/">Creative Commons Attribution-Noncommercial 4.0 License</a>.
Certificates logo by <a href="https://www.iconfinder.com/Flatart">Flatart</a><br>
Storage icon by <a href="https://www.iconfinder.com/iconic_hub">Dinosoftlab</a><br>
CI/CD icon made made by <a href="https://www.flaticon.com/authors/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>
Chaos Engineering logo made by Arie Bregman
